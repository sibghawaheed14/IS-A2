# Requirements audit: University Portal — updated source

This is a **source-and-tests assessment**, not a claim that every real-database/browser demo was executed in the grading environment. Mark tests completed only after running the project with MySQL and a browser.

| Rubric item | Specific implementation evidence | Expected Safe defense | Verification |
|---|---|---|---|
| Real-world platform | Login, dashboard, grade table, course search, course details, reviews, notices, account email | Same interface and functionality | Source verified; screenshot-reviewed clean frontend; local data-backed walkthrough required |
| Frontend + backend | `*/frontend/index.html`, Express `*/backend/server.js` | Both DB-backed via mysql2 | Source checked; MySQL integration pending local setup |
| Two switchable versions | `vulnerable/` on 3001, `safe/` on 3002, header link | Separate databases and session cookie names | Source checked |
| Reflected XSS | Vulnerable `/api/greet` text/html + `greetBox.innerHTML` | Safe `text/plain` + `textContent`, CSP | Source + isolated Chromium browser UI regression passed; live Express/browser demo needed |
| Stored XSS | Real SQL reviews table + unsafe `reviewsContainer.innerHTML` | Safe authenticated write and text-only rendering | Source + isolated Chromium browser UI regression passed; MySQL/browser demo needed |
| DOM XSS | `location.hash` → unsafe `innerHTML` | `textContent`, no inline JS in safe | Source + isolated Chromium browser UI regression passed; live Express/browser demo needed |
| CSRF | Real POST change-email; `attacker/index.html` cross-origin HTML form | Synchronizer token verified server-side; same-origin token acquisition | Source checked; true browser-cookie test pending on Windows |
| SQLi Easy | Interpolated login SQL | Server-side prepared lookup + salted hash verification | Source checked; MySQL test pending in Windows XAMPP |
| SQLi Intermediate | Interpolated `COUNT` with boolean-only return | Parameterized blind lookup | Source checked; MySQL test pending in Windows XAMPP |
| SQLi Advanced | Raw detail ID; 5 columns; `information_schema` chain | Full integer validation, prepared lookup, permission isolation | Source checked; MySQL test pending in Windows XAMPP |
| Defenses properly implemented | Auth-bound review/email updates, minimal session data, secure DOM, CSP, protected state mutations | Lab-safe behavior tested by integration suite | 16 source checks + 10 isolated browser cases passed; real DB/CSRF tests still required |
| Submission | Single repo, clear README, SQL import, attacker origin, reproducible tests, exact demo guide | No real user data, loopback binding | Source checked; GitHub push by student |

## Changes compared with uploaded ZIP

1. Removed the unrelated Healthcare Portal and duplicate nested Git repository from the deliverable; the assignment is now **one coherent University Portal project**.
2. Fixed demonstration notes for reflected XSS (a `<script>` inserted through `innerHTML` is not executed; an injected image `onerror` handler is).
3. Replaced the supposed Intermediate UNION dump with a **boolean-blind** SQL oracle that only returns true/false.
4. Corrected Advanced SQLi column mapping; the original payload attempted to place a text database name into numeric `id` and could not present the proper enumeration reliably.
5. Made advanced Course Detail input URL-encode payload bytes correctly.
6. Replaced an unreliable JSON/fetch attacker from an unserved local file with a real **different-origin HTML form POST** from `127.0.0.1:4000`; accurately document same-site vs cross-site cookie behavior.
7. Gave each version its own database and session cookie to avoid cross-contamination and session overwriting.
8. Removed plaintext passwords from the **Safe** schema, using salted scrypt; used prepared SQL on every safe read/write, not just the named three injection routes.
9. Protected login, review posting, account email update and logout with a session-bound CSRF token; stopped trusting a user-supplied review author ID.
10. Moved Safe JavaScript to an external file, removed inline event handlers, and enabled restrictive CSP + security headers.
11. Added a visible **current email from database** so a CSRF attacker can be verified by before/after state rather than trusting attacker-page messages.
12. Added a database health route, repeatable integration tests, static source assertions, and a detailed examiner walkthrough.

## Known demo limitations

- The attacker page demonstrates cross-**origin** CSRF between ports on the **same site**, not two different top-level websites. This is genuine cross-origin request forgery; a true cross-site POST would require a different HTTPS/cookie configuration. The token is the effective Safe defense even against a same-site cross-origin attacker.
- Local HTTP means the safe cookie has `secure: false`; use `secure: true` behind HTTPS outside a localhost lab.
- Safe uses Express MemoryStore and a randomly generated default session secret on every process start. Production should use persistent hardened sessions and configured secrets.
- Tests create stored-demo reviews, so reset dedicated lab DBs with `schema.sql` for a clean demonstration.
- Source checks do **not** prove that JavaScript executed in a browser or SQL ran against a live MySQL server. Run the integration tests and browser demonstrations on the student's local MySQL setup before claiming all requirements are met.

## Additional corrections after failed student browser demonstrations (2026-10-14)

- **Reflected XSS:** The original instructions used `onerror=alert('Reflected XSS')` without enclosing quotes. A space within an unquoted HTML attribute corrupts the handler, preventing the dialog. Updated all payload instructions and the Word evidence template to `onerror="alert('Reflected XSS')"`. The unchanged vulnerable `/api/greet` still emits real unsafe HTML and the browser now executes the correctly quoted handler. Safe remains `text/plain` + `textContent`.
- **DOM-based XSS:** The original vulnerable frontend only read `location.hash` on `load`, so changing the hash after sign-in never invoked it. It now reads the hash on initial load **and** `hashchange`, and automatically shows the Announcements tab while authenticated. Safe also displays the changed fragment as literal text. Both restore an existing authenticated session after refresh.
- **Normal student-facing interface:** Removed visible attack payloads, SQL injection walkthroughs, CVE/OWASP labels, defense-internals callouts and demo passwords from both portals. The application remains usable with clean forms and features; lab instructions are in `docs/ATTACK_LAB.md` only.
- **Course detail presentation:** Both portals show normal data in a readable table instead of raw JSON. The vulnerable advanced SQL injection still yields all five selected columns and can display rows returned by real `UNION` queries.
- **CSRF attacker-page presentation:** Styled the separate third-party page as a simple fictional campus benefit website; retained its real cross-origin form POST and safe-port comparison button. Attack steps are in documentation, not in either portal.
- **Verification:** Browser UI fixtures now assert popup execution/nonexecution in Chromium for all three XSS rendering paths in both versions, normal login/dashboard and course details, and hidden attack instructions. These fixtures are clearly labeled as not exercising the MySQL backend.
