# Attack demonstrations and evidence checklist (localhost only)

The following payloads are for **YOUR OWN** `127.0.0.1` University Portal copy with the **fictional data** created by `schema.sql`. Do not try them on a real university or other third-party service.

## Before recording

1. Set up the actual MySQL database, then run the `vulnerable` portal (port **3001**), `safe` portal (port **3002**) and `attacker` page (port **4000**) as in README.
2. Confirm `http://127.0.0.1:3001/api/health` and `http://127.0.0.1:3002/api/health` both return `{"database":"ok",...}`.
3. Keep Chrome DevTools **Network** and **Console** visible in screenshots, and capture the result from both versions for each requirement.
4. Log in with `alice_s` / `alice123` except when explicitly demonstrating login SQL injection.
5. If a demo leaves a malicious review in the DB, either delete it through a separate admin DB tool or reset the **lab-only** databases using `schema.sql` after collecting evidence.

## 1. Reflected XSS (immediate, server-side reflection)

- **Where:** Greeting tab; backend `GET /api/greet?name=...` responds with unsanitized `text/html`. **The application interface intentionally contains no test instructions: use this document while collecting evidence.**
- **Payload to paste in the Greeting name input:**

  ```html
  <img src=x onerror="alert('Reflected XSS')">
  ```

- **Vulnerable result:** clicking Greet Me fetches the HTML; the frontend uses `innerHTML`, so the broken image's **quoted** `onerror` handler opens the browser alert. (Without the quotes, `alert('Reflected XSS')` breaks at the space inside the attribute and may not execute.) The payload is not persisted in MySQL.
- **Additional direct-response proof:** visit `http://127.0.0.1:3001/api/greet?name=%3Cscript%3Ealert(1)%3C%2Fscript%3E` directly in the browser to demonstrate that the server returns executable HTML. **Note:** a `<script>` element dynamically inserted *by `innerHTML`* does **not** execute. Use the `<img onerror>` payload for the **in-app** demo.
- **Safe result:** same payload appears literally in the Greeting tab; API responds as `text/plain`, code uses `textContent`, and restrictive CSP blocks inline script.
- **Evidence:** screenshot vulnerable alert, GET response content type, safe visible text with no alert.

## 2. Stored XSS (persists in a SQL table)

- **Where:** Reviews tab, real MySQL `reviews.content` field.
- **Payload to paste in the review box:**

  ```html
  <img src=x onerror="alert('Stored XSS')">
  ```

- **Vulnerable result:** select a course, click Post Review, then Load Reviews. Malicious review comes back from MySQL and the `innerHTML` sink executes the handler. Log out, sign in as another student, Load Reviews: the stored payload still executes.
- **Safe result:** log in to port 3002 and submit the same payload in its review form. It saves the text to the safe database, but `textContent` renders tags literally. Unauthenticated posts or posts without a CSRF token receive 401/403.
- **Evidence:** `SELECT id,content FROM university_portal_vulnerable.reviews ORDER BY id DESC LIMIT 2;` + screenshot executed alert; safe displayed literal string.

## 3. DOM-based XSS (only browser-side, server never sees hash)

- **Where:** Announcements/Notice Board tab; JavaScript reads `location.hash` and inserts raw HTML.
- **Vulnerable URL (paste directly in address bar):**

  ```text
  http://127.0.0.1:3001/#%3Cimg%20src%3Dx%20onerror%3D%22alert%28%27DOM%20XSS%27%29%22%3E
  ```

- **Decoded payload** (shown for readability; the URL above is the copy/paste version):

  ```html
  <img src=x onerror="alert('DOM XSS')">
  ```

- **Vulnerable result:** sign in first, open **Announcements**, then paste the URL above into the same tab's address bar and press Enter. The new `hashchange` event updates the notice board without asking the server; the quoted image-error handler opens the alert. The `#fragment` is never sent to the server. If you try the same hash twice, clear the hash first and repeat.
- The application restores a valid session after page reload, so the Announcements panel remains reachable with the same account.
- **Safe result:** switch port to `3002`; no script runs. The literal string is displayed as notice-board text. Verify the hash does not appear in the Network request path.
- **Evidence:** alert, Console/Network showing fragment stays client-side, safe literal display.

## 4. CSRF (genuine cross-origin HTML form)

- **Where:** `POST /api/change-email`; updates actual MySQL `users.email` for the currently logged-in account.
- **Steps:**
  1. Sign in to `http://127.0.0.1:3001` as `alice_s` and open the Account tab. Record the **Current email (from database)**.
  2. In a new tab, open `http://127.0.0.1:4000` (the separately hosted attacker page), click **Send malicious POST to Vulnerable Portal**.
  3. Switch back to the victim's Account tab, visit another tab and reopen Account to refresh its database value. The new email is `compromised@attacker.test`. The victim's own account form was not submitted.
  4. Repeat against the safe portal with **Connect protected account**. Email remains unchanged; Safe returns `403` for the POST with no CSRF token.
- **Why it works:** different ports = **different origins**, and a form may submit across origins without CORS. Both are on the same *site* (`127.0.0.1`), so modern Lax cookies can still be sent. The vulnerable endpoint has no synchronizer token or Origin check.
- **Why Safe rejects:** Safe requires a server-generated, session-bound token on login/reviews/email-change/logout actions, plus a strict cookie policy. **SameSite=Strict on its own is not enough for this same-site, cross-origin attacker**; the CSRF token is the decisive protection.
- **Evidence:** before/after account email screenshot; Network request showing POST and cookies to vulnerable endpoint; safe HTTP 403 + unchanged database row.

## 5. SQL Injection EASY — Authentication bypass

- **Where:** Login page, `POST /api/login`.
- **Username** (the space after two hyphens must be preserved; `-- -` is paste-friendly):

  ```sql
  ' OR '1'='1' -- -
  ```

- **Password:** `anything-wrong`.
- **Vulnerable result:** login succeeds as the first returned user (`admin`) despite wrong credentials. This demonstrates a genuine SQL query whose `WHERE` condition has been altered.
- **Safe result:** login fails with 401; safe backend uses `mysql2.execute()` and verifies a salted scrypt password hash.
- **Evidence:** submitted payload, response role `admin`, safe 401.

## 6. SQL Injection INTERMEDIATE — Boolean-blind inference

- **Where:** Course Search tab → **Course Availability**. `GET /api/courses/availability?q=...` returns *only* `{ "available": true/false }`.
- **Probe for the FIRST character of admin's password being `a` (TRUE):**

  ```sql
  %' AND (SELECT SUBSTRING(password,1,1) FROM users WHERE username='admin')='a' -- -
  ```

- **Compare to a FALSE probe with `z`:**

  ```sql
  %' AND (SELECT SUBSTRING(password,1,1) FROM users WHERE username='admin')='z' -- -
  ```

- **Vulnerable result:** first request responds `{ "available": true }`; second responds `{ "available": false }`. The application does *not* return usernames or passwords. The attacker must infer unknown data by asking a sequence of true/false questions. This is materially more difficult than a direct UNION-based dump.
- **Safe result:** both payloads are treated as literal text search values in prepared `LIKE ?` queries; both result in `false` for the seeded course names. Ordinary course searches like `Data` still return true.
- **Evidence:** two GET requests and boolean-only JSON responses in DevTools + Safe comparison.

## 7. SQL Injection ADVANCED — Complete structured extraction chain

- **Where:** Course Search tab → Course Detail ID; backend `GET /api/courses/:id` uses the provided path literally in `WHERE id = ...`.
- **The original table query returns FIVE columns** in this order:

  ```text
  id (INT), code (VARCHAR), title (VARCHAR), credits (INT), lecturer_id (INT)
  ```

- **Step A: find column count** (five works, six triggers SQL error):

  ```sql
  1 ORDER BY 5 -- -
  1 ORDER BY 6 -- -
  ```

  The browser's Course Detail box shows the results/errors. `ORDER BY 5` works because the SELECT has five columns. `ORDER BY 6` causes a MySQL error. Optionally demonstrate `0 UNION SELECT 999,'MARKER','VISIBLE',0,0 -- -` to prove that columns 2 and 3 display strings.

- **Step B: identify current database and enumerate tables through `information_schema.tables`:**

  ```sql
  0 UNION SELECT 900,DATABASE(),'database',0,0 -- -
  0 UNION SELECT 901,table_schema,table_name,0,0 FROM information_schema.tables WHERE table_schema=DATABASE() -- -
  ```

  The current database appears in the `code` field as `university_portal_vulnerable`; tables `users`, `courses`, `reviews`, `enrollments` appear in the `title` field.

- **Step C: enumerate columns in target table through `information_schema.columns`:**

  ```sql
  0 UNION SELECT 902,table_name,column_name,0,0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' -- -
  ```

  Observe `username`, `password`, `email`, `role`, `api_token`. Strings use **columns 2 and 3**, not the numeric ID column, so names do not disappear via numeric coercion.

- **Step D: extract synthetic sensitive data from the discovered table:**

  ```sql
  0 UNION SELECT 903,username,password,0,0 FROM users -- -
  ```

  Observe `admin` / `admin123` and other **fictional** credential pairs in `code` / `title`. The restricted SQL lab DB user does not have SELECT permission to the safe database.

- **Safe result:** each non-integer detail ID is rejected with HTTP `400`; a legitimate numeric `1` still returns the actual course detail. The safe database account has separate permissions and no plaintext-password column.
- **Evidence:** screenshot **column-count success and failure**, database name, table names, target columns, extracted fictional credentials, and the matching Safe HTTP 400 rejection for every stage. Use the **Course Search → Course Detail → Course ID** input (not phpMyAdmin's SQL editor).

## Minimum examiner presentation route

1. Two browser tabs: port 3001 and port 3002 — identical core screens but different badges. Show both DBs via `SHOW DATABASES`.
2. Demonstrate **each vulnerable attack end to end**, followed immediately by its Safe counterpart.
3. For advanced SQLi, do not jump directly to credentials; show column count → DB/table enumeration → column enumeration → data extraction in order.
4. Finish with `npm run test:static` and `npm test` results from an environment running MySQL.
5. Include screenshots and indicate exactly which claims were manually or automatically verified. Never present untouched source-code claims as executed browser evidence.
