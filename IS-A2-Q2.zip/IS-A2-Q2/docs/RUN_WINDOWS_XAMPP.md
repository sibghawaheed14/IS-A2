# Running UniPortal on Windows with XAMPP (MariaDB/MySQL)

You do not need Docker if XAMPP is already installed. **Never upload either running portal to the internet:** the vulnerable server intentionally accepts dangerous inputs.

## 1. Start the database

1. Open **XAMPP Control Panel**, and start **Apache** (for phpMyAdmin) and **MySQL**. Both should turn green.
2. Open <http://localhost/phpmyadmin/>.
3. At the **server/home** level choose **Import**, select the project's `schema.sql` and click **Go**. Do **not** import it into an unrelated database.
4. Confirm both new databases exist on the left: `university_portal_vulnerable` and `university_portal_safe`.
5. **Warning:** `schema.sql` drops/recreates only those two *training* databases. Re-importing clears previous demo reviews and resets email addresses. Do not import again just because you downloaded an updated ZIP.

The script also creates restricted MySQL users, `uni_vuln_lab` / `local-lab-vulnerable` and `uni_safe_lab` / `local-lab-safe`. Only the database import should use a MySQL admin account; **do not configure the vulnerable backend to use XAMPP's root MySQL account**.

## 2. Open the correct project folder

Extract the ZIP and **locate the folder containing `schema.sql`, `package.json`, `vulnerable`, `safe`, and `attacker` together**. Windows ZIP tools can produce two nested folders with the same name. In VS Code, use **Terminal → New Terminal → PowerShell**.

Confirm Node.js with:

```powershell
node -v
npm -v
```

## 3. Run the three servers (PowerShell)

In Terminal 1, starting from your project root:

```powershell
cd vulnerable/backend
npm install
npm start
```

In Terminal 2, starting from your project root:

```powershell
cd safe/backend
npm install
npm start
```

In Terminal 3, starting from your project root:

```powershell
node attacker/server.js
```

Open <http://127.0.0.1:3001/> (Vulnerable), <http://127.0.0.1:3002/> (Safe), and <http://127.0.0.1:4000/> (attacker site). Keep all three terminals open.

**Important:** If your terminal is *already inside* the `attacker` folder, run `node server.js` instead. Do not use `node attacker/server.js` from inside `attacker` (that looks for a nonexistent nested path).

Demo user: `alice_s` / `alice123`.

## 4. Check the database connection

- <http://127.0.0.1:3001/api/health>
- <http://127.0.0.1:3002/api/health>

Both should show `"database":"ok"`. If the response is `"database":"offline"`, check the XAMPP MySQL port (default is **3306**), the imported schemas, and the MySQL users. If XAMPP uses port 3307, set `$env:DB_PORT='3307'` **separately in each server's PowerShell terminal before `npm start`**.

## 5. Use the separate private testing guide

The student-facing portal intentionally contains no payloads or attack instructions. Open [`ATTACK_LAB.md`](ATTACK_LAB.md) for copy/paste payloads, which field to use, and screenshot evidence for each requirement.

For browser alerts, an attribute with spaces in the message **must quote the whole JavaScript handler**, for example:

```html
<img src=x onerror="alert('Reflected XSS')">
```

For DOM-based XSS, **log in, open Announcements, then paste the provided URL into the address bar**. The fragment handler now responds to URL changes after login.

## 6. Run checks

From your project root:

```powershell
npm run test:static
npm test
```

The integration suite requires XAMPP MySQL and both portal servers running; it performs real DB operations. The optional `tests/browser_ui_smoke.py` uses local Chromium and isolated HTTP fixtures to verify the frontend event/DOM behavior; it **does not** prove SQL injection or persistence in XAMPP.

## 7. When replacing the previous ZIP

1. Stop the 3001/3002/4000 Node servers with `Ctrl+C`.
2. Extract the updated ZIP into a **new folder**, then reopen that new folder in VS Code. Do not mix old frontend files with new backend files.
3. **Keep the existing XAMPP databases**. Their tables are compatible; you should not need to re-import `schema.sql`.
4. Start the servers from the updated folder. Use `Ctrl+Shift+R` in Chrome for a hard refresh to avoid showing cached old HTML/JavaScript.
5. Record real screenshots on your Windows computer, then attach them to your report.
