# Fix summary — clean University Portal UI and reliable browser XSS demos

## Problems reproduced

1. The student's reported Reflected XSS input included an `onerror` HTML attribute **without quotes** around the handler containing spaces. Chrome parsed the handler incorrectly (`alert('Reflected XSS')` was split into multiple attributes), so the JavaScript never completed.
2. The vulnerable DOM fragment was rendered only from a `window.load` listener. Changing the URL's `#fragment` after login does not reload the page, so the handler did not run; the notice board was not updated.
3. Both public portals visibly displayed payload samples, SQL injection steps, security defenses, and even sample passwords. This was inconsistent with the assignment's realistic use-case interface requirement. The Safe Portal also lacked a reverse toggle link.
4. Course detail returned raw JSON instead of a readable academic page. Reloading both portals required signing in again despite the server retaining an authenticated session.
5. The previously supplied Word evidence workbook repeated the malformed payloads and old interface/button messages.

## Corrections

- **Reflected XSS:** the backend and deliberately unsafe `innerHTML` path remain genuine. The testing guide now uses `<img src=x onerror="alert('Reflected XSS')">` and clearly distinguishes *direct HTML response execution* from dynamically inserting an inert `<script>` through `innerHTML`.
- **DOM XSS:** added `hashchange` handling, safe URI decoding, automatic Announcements tab selection, and existing-session restoration on both versions. The **vulnerable** version continues to pass the decoded hash to `innerHTML`; the **safe** version creates text nodes only.
- **Clean UI:** removed student-facing `Attack Payload`, SQLi cheat sheets, defense explanations, and default credentials. Added mode toggles in both directions and maintained identical core features.
- **Readability:** course detail now renders a table of five fields, preserving visibility of all UNION rows in the vulnerable advanced SQL injection path. Both versions have human-readable availability labels.
- **CSRF:** kept a real external-origin HTML form against the two local ports, but moved technical setup into documentation and made the attacker fixture resemble a fictional campus benefits page.
- **Evidence:** fixed all reflected/stored/DOM payloads in `docs/ATTACK_LAB.md` and the editable Word evidence workbook. Added Windows/XAMPP setup instructions and optional Chromium browser fixture tests.

## Evidence and limits

- `node tests/static-checks.mjs`: 16/16 source checks passed.
- `python tests/browser_ui_smoke.py`: 10/10 actual Chromium frontend cases passed using **stubbed API responses**. These tests prove corrected browser event behavior but are **not** real database exploitation evidence.
- SQLi/CSRF correctness still requires `npm test`, a live XAMPP MySQL/MariaDB instance and manual browser screenshots on Windows.
- Do **not** publish or expose the Vulnerable app outside `127.0.0.1`.
