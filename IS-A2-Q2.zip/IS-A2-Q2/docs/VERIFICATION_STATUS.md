# Verification status — revised lab (2026-10-14)

The coursework includes intentionally exploitable source code. **Do not describe an attack as demonstrated until it succeeds in your own browser and real MySQL/MariaDB installation.** The two portals and attacker page must stay on loopback (`127.0.0.1`); never publish the vulnerable server.

## Checks performed in this correction

| Check | Result | Scope |
|---|---|---|
| `node tests/static-checks.mjs` | **16/16 passed** | Source-level structure, XSS sinks vs defenses, prepared SQL, CSRF, scoped DB users, no visible payload instructions, `hashchange` handler and exact payload guide |
| `python tests/browser_ui_smoke.py` | **10/10 browser cases passed** | Actual HTML + JavaScript rendered in Chromium. **Fixtures** substitute for unavailable HTTP/MySQL services; checks popup/non-popup for reflected, DOM, and review-rendering XSS, normal portal login UI, normal course-detail table and clean interface in both modes |
| `node --check` | **Passed** | Vulnerable backend JS, safe backend JS, safe frontend JS, attacker server JS, integration tests, source checks |
| Attacker page HTTP | **200 on localhost:4000** | Node's built-in server serves the HTML fixture; does not establish successful CSRF |
| Word evidence template | **Rendered / visually reviewed** | 19-page editable DOCX; corrected quoted XSS payloads, DOM encoded URLs, new attacker button names, availability output |

The browser UI test explicitly uses fake responses so it can run without MariaDB; it **cannot** prove database persistence, real SQLi, real CSRF cookie delivery, or backend authentication. The separate `tests/integration.mjs` exercises genuine SQL/HTTP behavior, and must be run with XAMPP MySQL and both Node backends running.

## Checks that remain pending on the student's Windows computer

1. Import `schema.sql` into XAMPP / phpMyAdmin and confirm both `/api/health` endpoints return `database:ok`.
2. Run **`npm test`** and record the actual count. The tests require both Express servers and seeded MySQL databases.
3. With Chrome, demonstrate the exact **quoted** payloads in `docs/ATTACK_LAB.md`: reflected XSS (vulnerable alert / safe text), stored review XSS (real SQL persistence / safe text), DOM URL fragment XSS (vulnerable alert / safe literal content).
4. From the independently hosted `http://127.0.0.1:4000` page, verify the vulnerable email changes via a genuine cross-origin authenticated HTML form; verify the Safe server rejects the equivalent request and email remains unchanged.
5. Demonstrate Easy/Intermediate/Advanced SQL injection against the real local SQL database, including all advanced enumeration stages and the blocked Safe counterparts.
6. Place authentic screenshots in the included Word evidence template; never use simulated screenshots as grading evidence.

## Why end-to-end MySQL checks are not reported as passed here

This environment has no running MySQL/MariaDB server, and external npm registry access is unavailable. The student already has a Windows XAMPP environment; complete real-DB tests there. Existing project schemas and package-lock files are retained. No GitHub submission has been performed.
