// Deliberate attacker origin on a second LOOPBACK-only port. Uses only Node built-ins.
const http = require('http');
const fs = require('fs');
const path = require('path');
http.createServer((req, res) => {
    if (req.url !== '/' && req.url !== '/index.html') {
        res.writeHead(404).end('Not found'); return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    fs.createReadStream(path.join(__dirname, 'index.html')).pipe(res);
}).listen(4000, '127.0.0.1', () => console.log('Attacker demo: http://127.0.0.1:4000'));
