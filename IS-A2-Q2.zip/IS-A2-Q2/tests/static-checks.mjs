import { readFileSync } from 'node:fs';
import { strict as assert } from 'node:assert';
import { join } from 'node:path';
const root = new URL('../', import.meta.url);
const read = path => readFileSync(new URL(path, root),'utf8');
const vBackend=read('vulnerable/backend/server.js');
const sBackend=read('safe/backend/server.js');
const vHtml=read('vulnerable/frontend/index.html');
const sHtml=read('safe/frontend/index.html');
const safeJs=read('safe/frontend/app.js');
const attacker=read('attacker/index.html');
const sql=read('schema.sql');
const guide=read('docs/ATTACK_LAB.md');
const checks = [
 ['Two separate functioning Express backends', ()=>{assert.match(vBackend,/express\(/);assert.match(sBackend,/express\(/);}],
 ['Both have real MySQL query driver', ()=>{assert.match(vBackend,/mysql2/);assert.match(sBackend,/mysql2\/promise/);}],
 ['Separation of vulnerable/safe data and cookies',()=>{assert.match(sql,/university_portal_vulnerable/);assert.match(sql,/university_portal_safe/);assert.match(vBackend,/uni\.vulnerable\.sid/);assert.match(sBackend,/uni\.safe\.sid/);} ],
 ['Easy SQLi vulnerable interpolation vs safe prepared query',()=>{assert.match(vBackend,/WHERE username = '\$\{username\}'/);assert.match(sBackend,/db\.execute\('SELECT id, username, password_hash, role FROM users WHERE username = \?',/);} ],
 ['Intermediate SQLi sends boolean-only response',()=>{assert.match(vBackend,/WHERE title LIKE '%\$\{q\}%'`/);assert.match(vBackend,/available: !!\(rows\[0\]/);assert.match(sBackend,/SELECT COUNT\(\*\) AS matches FROM courses WHERE title LIKE \?/);} ],
 ['Advanced SQLi raw path vs full validation and binding',()=>{assert.match(vBackend,/WHERE id = \$\{req\.params\.id\}/);assert.match(sBackend,/const id = validId\(req\.params\.id\)/);assert.match(sBackend,/WHERE id = \?', \[id\]/);} ],
 ['Reflected XSS unsafe HTML vs safe plain text',()=>{assert.match(vBackend,/res\.type\('html'\)\.send/);assert.match(sBackend,/res\.type\('text\/plain'\)/);assert.match(vHtml,/greetBox'\)\.innerHTML = html/);assert.match(safeJs,/greetBox'\)\.textContent = msg/);} ],
 ['Stored XSS unsafe innerHTML vs safe textContent',()=>{assert.match(vHtml,/box\.innerHTML = rows\.map/);assert.match(safeJs,/content\.textContent = r\.content/);} ],
 ['DOM-XSS client-side URL fragment unsafe vs safe',()=>{assert.match(vHtml,/notesBox'\)\.innerHTML =/);assert.match(safeJs,/decodeURIComponent\(location\.hash/);assert.match(safeJs,/div\.textContent = text/);} ],
 ['Safe page compatible with strict script CSP',()=>{assert.doesNotMatch(sHtml,/onclick=|<script>/i);assert.match(sHtml,/<script src="\/app\.js" defer>/);assert.doesNotMatch(safeJs,/\.innerHTML|document\.write|eval\(/);assert.match(sBackend,/scriptSrc: \["'self'"\]/);} ],
 ['CSRF forged form is a real post to vulnerable API, safe token required',()=>{assert.match(attacker,/method="POST"/);assert.match(attacker,/target="hiddenResponse"/);assert.match(sBackend,/app\.post\('\/api\/change-email', csrfRequired, requireLogin/);assert.match(sBackend,/app\.post\('\/api\/reviews', csrfRequired, requireLogin/);assert.match(sBackend,/app\.post\('\/api\/logout', csrfRequired, requireLogin/);} ],
 ['Safe data is salted scrypt, attacker DB synthetic plaintext',()=>{assert.match(sql,/password_hash/);assert.match(sql,/scrypt\$[0-9a-f]{32}\$[0-9a-f]{128}/);assert.match(sql,/admin123/);} ],
 ['SQLi advanced enumeration uses information_schema and privilege isolation',()=>{assert.match(guide,/information_schema\.tables/);assert.match(guide,/information_schema\.columns/);assert.match(sql,/GRANT SELECT, INSERT, UPDATE ON university_portal_vulnerable/);} ],
];
checks.push(
  ['Real course portal UI contains no attack instructions', () => {
    for (const html of [vHtml, sHtml]) {
      assert.doesNotMatch(html, /class="attack-info"|class="defense-info"|SQL Injection Laboratory|Attack Chain|Try any SQLi|CSRF TOKEN \+ SameSite|XSS Fixed/i);
      assert.doesNotMatch(html, /<span class="badge-(?:vuln|safe)">/);
    }
  }],
  ['DOM fragment handler runs after hashchange on vulnerable page', () => {
    assert.match(vHtml, /window\.addEventListener\('hashchange',\s*renderFragment\)/);
    assert.match(vHtml, /function renderFragment\(/);
  }],
  ['Manual screenshot guide uses quoted XSS event attributes', () => {
    assert.ok(guide.includes('onerror="alert(\'Reflected XSS\')"'));
    assert.ok(guide.includes('onerror="alert(\'DOM XSS\')"'));
  }],
);

let count=0;
for (const [name,check] of checks) {
 try {check(); count++;console.log('PASS',name);}
 catch(e){console.error('FAIL',name,e.message);process.exitCode=1;}
}
console.log(`${count}/${checks.length} source-code checks passed. Database/Browser E2E must be run separately.`);
