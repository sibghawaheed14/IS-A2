"""Browser-only regressions for the REAL frontend files using isolated response fixtures.

This does not test MariaDB persistence, Express security headers, or cross-origin cookies.
Prerequisites: pip install playwright, then install Chromium or Chrome locally.
"""
from pathlib import Path
import re
from shutil import which
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
GOOD = '<img src=x onerror="alert(\'Browser XSS\')">'


def exercise(page, mode):
    page.set_default_timeout(3500)
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    dialogs = []
    page.on('dialog', lambda dialog: (dialogs.append(dialog.message), dialog.accept()))
    source = (ROOT / mode / 'frontend/index.html').read_text(encoding='utf-8')
    source = re.sub(r'<link[^>]+fonts\.googleapis\.com[^>]+>', '', source)
    source = re.sub(r'<link[^>]+rel="preconnect"[^>]+>', '', source)
    if mode == 'safe':
        source = source.replace('<script src="/app.js" defer></script>', '')
    page.set_content(source, wait_until='domcontentloaded')

    # Isolated HTTP fixtures permit click/DOM tests without pretending SQL was run.
    page.evaluate('''(mode) => {
        window.fetch = async (path) => {
            const route = new URL(path, 'http://127.0.0.1:3001');
            const user = { id: 3, username: 'alice_s', role: 'student', email: 'alice@student.test' };
            let data = {}, type = 'application/json';
            if (route.pathname === '/api/csrf-token') data = { csrfToken: 'fixture-token' };
            else if (route.pathname === '/api/login') data = { success: true, user, csrfToken: 'fixture-token' };
            else if (route.pathname === '/api/me') data = user;
            else if (route.pathname === '/api/my-enrollments') data = [{ code:'CS101', title:'Introduction to Computer Science', credits:3, grade:'A' }];
            else if (route.pathname === '/api/courses/1') data = [{id:1, code:'CS101', title:'Introduction to Computer Science', credits:3, lecturer_id:2}];
            else if (route.pathname === '/api/reviews') data = [{id:1, content:'<img src=x onerror="alert(\\'Browser XSS\\')">',course_id:1,created_at:'2026-10-14',username:'alice_s'}];
            else if (route.pathname === '/api/greet') {
                const name = route.searchParams.get('name') || 'Student';
                data = mode === 'vulnerable'
                    ? `<h2>Welcome back, ${name}!</h2><p>You are logged into the University Portal.</p>`
                    : `Welcome back, ${name}! You are logged into the University Portal.`;
                type = mode === 'vulnerable' ? 'text/html' : 'text/plain';
            }
            else if (route.pathname === '/api/courses/availability') data = {available:true};
            else data = [];
            return {
                ok:true, headers:new Headers({'content-type':type}),
                json:async() => data,
                text:async() => typeof data === 'string' ? data : JSON.stringify(data)
            };
        };
    }''', mode)
    if mode == 'safe':
        page.add_script_tag(content=(ROOT / 'safe/frontend/app.js').read_text(encoding='utf-8'))

    if page.locator('#loginPanel').is_visible():
        page.locator('#username').fill('alice_s')
        page.locator('#password').fill('alice123')
        page.get_by_role('button', name='Login').click()
    page.locator('#mainApp').wait_for(state='visible')
    assert page.locator('#headerUser').inner_text().endswith('alice_s')
    if __import__('os').environ.get('UNI_VISUAL_QA'):
        page.screenshot(path=f'/mnt/data/uniportal_preview_{mode}.png', full_page=True)

    body = page.locator('body').inner_text()
    forbidden = ['Attack Payload', 'SQL Injection Laboratory', 'Attack Chain', 'Boolean-blind SQL injection defense', 'Defense: Prepared Statement', 'Stored XSS Fixed']
    assert not any(word in body for word in forbidden), f'{mode} still reveals attack instructions'
    print('PASS', mode, 'clean login and normal student dashboard')

    page.get_by_role('button', name='Course Search').click()
    page.locator('#courseId').fill('1')
    page.get_by_role('button', name='Get Detail').click()
    page.locator('#courseDetail').get_by_text('CS101').wait_for()
    assert 'Introduction to Computer Science' in page.locator('#courseDetail').inner_text()
    print('PASS',mode,'normal course details are rendered as a table')

    page.get_by_role('button', name='Greeting').click()
    page.locator('#greetName').fill(GOOD)
    page.get_by_role('button', name='Greet Me').click()
    page.wait_for_timeout(150)
    assert bool(dialogs) == (mode == 'vulnerable'), f'{mode} reflected popup mismatch {dialogs}'
    print('PASS',mode,'reflected XSS browser execution / blocking:',dialogs)
    dialogs.clear()

    page.get_by_role('button', name='Announcements').click()
    page.evaluate('(payload) => { location.hash = encodeURIComponent(payload); }', GOOD)
    page.wait_for_timeout(180)
    assert bool(dialogs) == (mode == 'vulnerable'), f'{mode} hashchange popup mismatch {dialogs}'
    if mode == 'safe':
        assert GOOD in page.locator('#notesBox').inner_text()
    print('PASS',mode,'DOM-based hashchange execution / blocking:',dialogs)
    dialogs.clear()

    page.get_by_role('button', name='Reviews').click()
    page.wait_for_timeout(240)
    assert bool(dialogs) == (mode == 'vulnerable'), f'{mode} review HTML rendering mismatch {dialogs}'
    if mode == 'safe':
        assert GOOD in page.locator('#reviewsContainer').inner_text()
    print('PASS',mode,'stored-review browser rendering (fixture only):',dialogs)
    assert not errors, f'{mode}: browser JavaScript errors {errors}'


def run():
    chromium = which('chromium') or which('google-chrome')
    if chromium is None:
        raise SystemExit('Chromium not found. This optional test requires a local Chromium/Chrome install.')
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True, executable_path=chromium, args=['--no-sandbox'])
        try:
            for mode in ('vulnerable', 'safe'):
                page = browser.new_page(viewport={'width':1280,'height':800}, device_scale_factor=1)
                try: exercise(page, mode)
                finally: page.close()
        finally: browser.close()
    print('Browser UI fixtures passed. Run npm test with MySQL and manual local CSRF tests separately.')

if __name__ == '__main__':
    run()
