/**
 * Intentionally vulnerable University Portal for an OWASP classroom lab.
 * ATTACK ONLY THIS LOCAL INSTANCE. Do not deploy or connect real accounts/data.
 */
const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const path = require('path');

const app = express();
const PORT = 3001;
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
    name: 'uni.vulnerable.sid', // Separate port instances must not overwrite cookies
    secret: 'insecure-classroom-session-secret', // DELIBERATELY insecure
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: false, sameSite: 'lax', secure: false }
}));
app.use(express.static(path.join(__dirname, '../frontend')));

const db = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'uni_vuln_lab',
    password: process.env.DB_PASSWORD || 'local-lab-vulnerable',
    database: 'university_portal_vulnerable',
    connectionLimit: 5,
    multipleStatements: false // UNION attacks need no stacked SQL or DDL permissions
});

db.query('SELECT 1', (err) => {
    if (err) console.error('[LAB] MySQL unavailable:', err.message);
    else console.log('[LAB] Connected to university_portal_vulnerable');
});

// Setup probe used by the automated MySQL-backed integration tests.
app.get('/api/health', (req, res) => {
    db.query('SELECT 1', (err) => {
        if (err) return res.status(503).json({ database: 'offline' });
        res.json({ database: 'ok', mode: 'vulnerable' });
    });
});

// EASY SQLi: login uses direct SQL interpolation. No validation/escaping.
app.post('/api/login', (req, res) => {
    const username = req.body.username || '';
    const password = req.body.password || '';
    const sql = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    db.query(sql, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!Array.isArray(rows) || rows.length === 0)
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        req.session.user = rows[0]; // DELIBERATELY stores excessive data in session
        res.json({ success: true, user: rows[0] });
    });
});

// Normal course search works on both versions. It is not the SQLi lab endpoint.
app.get('/api/courses/search', (req, res) => {
    const q = String(req.query.q || '');
    db.query('SELECT id, code, title, credits, lecturer_id FROM courses WHERE title LIKE ?',
        ['%' + q + '%'], (err, rows) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(rows);
        });
});

// INTERMEDIATE SQLi: boolean-blind oracle. ONLY a boolean is returned, never rows.
// Example: %' AND (SELECT SUBSTRING(password,1,1) FROM users WHERE username='admin')='a' -- 
app.get('/api/courses/availability', (req, res) => {
    const q = req.query.q || '';
    const sql = `SELECT COUNT(*) AS matches FROM courses WHERE title LIKE '%${q}%'`;
    db.query(sql, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ available: !!(rows[0] && Number(rows[0].matches) > 0) });
    });
});

// ADVANCED SQLi: UNION/info_schema enumeration in a five-column SELECT.
// Columns: id (integer), code (text), title (text), credits (integer), lecturer_id (integer).
// Numeric marker in column 1, extracted strings in code/title (columns 2 and 3).
app.get('/api/courses/:id', (req, res) => {
    const sql = `SELECT id, code, title, credits, lecturer_id FROM courses WHERE id = ${req.params.id}`;
    db.query(sql, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// REFLECTED XSS: response is HTML and includes untrusted query bytes verbatim.
app.get('/api/greet', (req, res) => {
    const name = req.query.name || 'Student';
    res.type('html').send(`<h2>Welcome back, ${name}!</h2><p>You are logged into the University Portal.</p>`);
});

// STORED XSS: payload is stored in a real database, later rendered via innerHTML.
app.post('/api/reviews', (req, res) => {
    const { user_id, course_id, content } = req.body;
    db.query('INSERT INTO reviews (user_id, course_id, content) VALUES (?, ?, ?)',
        [user_id, course_id, content], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true, id: result.insertId });
        });
});
app.get('/api/reviews', (req, res) => {
    const course_id = req.query.course_id || '';
    // Keep separate extra SQLi out of the reviews filter to make lab stages clearer.
    const sql = 'SELECT r.id, r.course_id, r.content, r.created_at, u.username FROM reviews r JOIN users u ON u.id = r.user_id' +
        (course_id ? ' WHERE r.course_id = ?' : '') + ' ORDER BY r.id DESC';
    db.query(sql, course_id ? [course_id] : [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows); // Deliberately no HTML encoding
    });
});

// CSRF: authenticated state change without token or Origin check.
// Browser allows a FORM POST sent from localhost:4000 (different origin, same site).
app.post('/api/change-email', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
    const email = req.body.email || '';
    db.query('UPDATE users SET email = ? WHERE id = ?', [email, req.session.user.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        req.session.user.email = email;
        res.json({ success: true, newEmail: email });
    });
});

app.get('/api/me', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
    const id = req.session.user.id;
    db.query('SELECT id, username, email, role FROM users WHERE id = ?', [id], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!rows.length) return res.status(404).json({ error: 'User missing' });
        res.json(rows[0]);
    });
});
app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ success: true })));
app.get('/api/my-enrollments', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
    db.query('SELECT e.grade, c.code, c.title, c.credits FROM enrollments e JOIN courses c ON e.course_id = c.id WHERE e.student_id = ?',
        [req.session.user.id], (err, rows) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(rows);
        });
});

app.listen(PORT, '127.0.0.1', () => {
    console.log(`INSECURE CLASSROOM LAB ONLY: http://127.0.0.1:${PORT}`);
});
