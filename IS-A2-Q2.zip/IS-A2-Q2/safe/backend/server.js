/** Hardened University Portal. Local teaching demo; not a production deployment. */
const express = require('express');
const mysql = require('mysql2/promise');
const session = require('express-session');
const helmet = require('helmet');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = 3002;
app.disable('x-powered-by');
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'"], // no inline JS, unsafe eval, data scripts, event handlers
            styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
            fontSrc: ["'self'", 'https://fonts.gstatic.com'],
            imgSrc: ["'self'", 'data:'],
            connectSrc: ["'self'"],
            objectSrc: ["'none'"],
            frameAncestors: ["'none'"],
            baseUri: ["'self'"],
            formAction: ["'self'"],
            // No HTTPS upgrade for this explicitly HTTP/localhost-only classroom lab.
            upgradeInsecureRequests: null
        }
    }
}));
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
    name: 'uni.safe.sid', // Prevent clashes with port 3001 cookie on same hostname
    secret: process.env.SAFE_SESSION_SECRET || crypto.randomBytes(48).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'strict', secure: false, maxAge: 60 * 60 * 1000 }
}));
app.use('/api', (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use(express.static(path.join(__dirname, '../frontend')));

const db = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'uni_safe_lab',
    password: process.env.DB_PASSWORD || 'local-lab-safe',
    database: 'university_portal_safe',
    connectionLimit: 5,
    multipleStatements: false
});
db.query('SELECT 1').then(() => console.log('[SAFE] Connected to university_portal_safe'))
    .catch(e => console.error('[SAFE] MySQL unavailable:', e.message));

function sendError(res, err) {
    console.error('[SAFE SERVER]', err.message);
    return res.status(500).json({ error: 'Server error' });
}
function validId(value) {
    const v = String(value);
    if (!/^[1-9]\d*$/.test(v)) return null;
    const n = Number(v);
    return Number.isSafeInteger(n) ? n : null;
}
function checkPassword(candidate, encoded) {
    if (typeof candidate !== 'string' || typeof encoded !== 'string') return false;
    const parts = encoded.split('$');
    if (parts.length !== 3 || parts[0] !== 'scrypt' || !/^[0-9a-f]{32}$/.test(parts[1]) || !/^[0-9a-f]{128}$/.test(parts[2])) return false;
    const expected = Buffer.from(parts[2], 'hex');
    const actual = crypto.scryptSync(candidate, Buffer.from(parts[1], 'hex'), 64);
    return crypto.timingSafeEqual(expected, actual);
}
function getCsrf(req) {
    if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    return req.session.csrfToken;
}
function csrfRequired(req, res, next) {
    const actual = req.get('CSRF-Token') || req.body?._csrf;
    const expected = req.session.csrfToken;
    if (typeof actual !== 'string' || !/^[0-9a-f]{64}$/.test(actual) || !expected)
        return res.status(403).json({ error: 'CSRF token missing or invalid' });
    if (!crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex')))
        return res.status(403).json({ error: 'CSRF token missing or invalid' });
    next();
}
function requireLogin(req, res, next) {
    if (!req.session.user) return res.status(401).json({ error: 'Login required' });
    next();
}

app.get('/api/health', async (req, res) => {
    try { await db.query('SELECT 1'); res.json({ database: 'ok', mode: 'safe' }); }
    catch (err) { res.status(503).json({ database: 'offline' }); }
});

// Session-bound synchronizer token for every state-changing API route.
app.get('/api/csrf-token', (req, res) => res.json({ csrfToken: getCsrf(req) }));

app.post('/api/login', csrfRequired, async (req, res) => {
    const { username, password } = req.body || {};
    if (typeof username !== 'string' || username.length > 50 || typeof password !== 'string' || password.length > 256)
        return res.status(401).json({ success: false, message: 'Invalid credentials' });
    try {
        const [rows] = await db.execute('SELECT id, username, password_hash, role FROM users WHERE username = ?', [username]);
        if (!rows.length || !checkPassword(password, rows[0].password_hash))
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        const user = { id: rows[0].id, username: rows[0].username, role: rows[0].role };
        // Fix session fixation: replace anonymous session after authentication.
        req.session.regenerate((err) => {
            if (err) return sendError(res, err);
            req.session.user = user;
            res.json({ success: true, user, csrfToken: getCsrf(req) });
        });
    } catch (err) { sendError(res, err); }
});

app.get('/api/courses/search', async (req, res) => {
    const q = req.query.q ?? '';
    if (typeof q !== 'string' || q.length > 200) return res.status(400).json({ error: 'Invalid query' });
    try {
        const [rows] = await db.execute(
            'SELECT id, code, title, credits, lecturer_id FROM courses WHERE title LIKE ?', ['%' + q + '%']);
        res.json(rows);
    } catch (err) { sendError(res, err); }
});

// SAFE BLIND-ORACLE COMPARISON: same availability feature, bound LIKE parameter.
app.get('/api/courses/availability', async (req, res) => {
    const q = req.query.q ?? '';
    if (typeof q !== 'string' || q.length > 200) return res.status(400).json({ error: 'Invalid query' });
    try {
        const [rows] = await db.execute('SELECT COUNT(*) AS matches FROM courses WHERE title LIKE ?', ['%' + q + '%']);
        res.json({ available: Number(rows[0].matches) > 0 });
    } catch (err) { sendError(res, err); }
});

app.get('/api/courses/:id', async (req, res) => {
    const id = validId(req.params.id);
    if (id === null) return res.status(400).json({ error: 'Invalid course ID' });
    try {
        const [rows] = await db.execute('SELECT id, code, title, credits, lecturer_id FROM courses WHERE id = ?', [id]);
        res.json(rows);
    } catch (err) { sendError(res, err); }
});

// Send plain text, not HTML; frontend inserts it only via textContent.
app.get('/api/greet', (req, res) => {
    const name = req.query.name ?? 'Student';
    if (typeof name !== 'string' || name.length > 200) return res.status(400).type('text').send('Invalid name');
    res.type('text/plain').send(`Welcome back, ${name}! You are logged into the University Portal.`);
});

app.post('/api/reviews', csrfRequired, requireLogin, async (req, res) => {
    const content = req.body?.content;
    const courseId = validId(req.body?.course_id);
    if (courseId === null || typeof content !== 'string' || !content.trim() || content.length > 2000)
        return res.status(400).json({ error: 'Invalid review content or course' });
    try {
        // User identity is read from trusted session, not an attacker-supplied user_id.
        const [result] = await db.execute('INSERT INTO reviews (user_id, course_id, content) VALUES (?, ?, ?)',
            [req.session.user.id, courseId, content]);
        res.json({ success: true, id: result.insertId });
    } catch (err) { sendError(res, err); }
});
app.get('/api/reviews', async (req, res) => {
    const course = req.query.course_id;
    const cid = course === undefined || course === '' ? null : validId(course);
    if (cid === null && course !== undefined && course !== '') return res.status(400).json({ error: 'Invalid course ID' });
    const sql = 'SELECT r.id, r.course_id, r.content, r.created_at, u.username FROM reviews r JOIN users u ON u.id = r.user_id' +
        (cid !== null ? ' WHERE r.course_id = ?' : '') + ' ORDER BY r.id DESC';
    try {
        const [rows] = cid !== null ? await db.execute(sql, [cid]) : await db.query(sql);
        // JSON retains original text; the browser renders it as textContent, never HTML.
        res.json(rows);
    } catch (err) { sendError(res, err); }
});

app.post('/api/change-email', csrfRequired, requireLogin, async (req, res) => {
    const email = req.body?.email;
    if (typeof email !== 'string' || email.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return res.status(400).json({ error: 'Invalid email address' });
    try {
        await db.execute('UPDATE users SET email = ? WHERE id = ?', [email, req.session.user.id]);
        res.json({ success: true, newEmail: email });
    } catch (err) { sendError(res, err); }
});
app.get('/api/me', requireLogin, async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT id, username, email, role FROM users WHERE id = ?', [req.session.user.id]);
        if (!rows.length) return res.status(404).json({ error: 'User missing' });
        res.json(rows[0]);
    } catch (err) { sendError(res, err); }
});
app.post('/api/logout', csrfRequired, requireLogin, (req, res) => {
    req.session.destroy((err) => {
        if (err) return sendError(res, err);
        res.clearCookie('uni.safe.sid');
        res.json({ success: true });
    });
});
app.get('/api/my-enrollments', requireLogin, async (req, res) => {
    try {
        const [rows] = await db.execute(
            'SELECT e.grade, c.code, c.title, c.credits FROM enrollments e JOIN courses c ON e.course_id = c.id WHERE e.student_id = ?',
            [req.session.user.id]);
        res.json(rows);
    } catch (err) { sendError(res, err); }
});

app.use((err, req, res, next) => { sendError(res, err); });
app.listen(PORT, '127.0.0.1', () => console.log(`HARDENED LAB: http://127.0.0.1:${PORT}`));
