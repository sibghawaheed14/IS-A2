'use strict';
// SAFE VERSION: ALL event handlers are registered here (CSP forbids inline JS).
// Untrusted text is rendered through textContent, never innerHTML.
const $ = id => document.getElementById(id);
let CSRF_TOKEN = '';

async function api(url, options = {}) {
    const response = await fetch(url, { credentials: 'same-origin', ...options });
    const type = response.headers.get('content-type') || '';
    const data = type.includes('application/json') ? await response.json() : await response.text();
    if (!response.ok) throw new Error(typeof data === 'object' ? (data.error || data.message || 'Request failed') : data);
    return data;
}
function status(id, message, success = true) {
    const parent = $(id);
    if (!parent) return;
    const messageBox = document.createElement('div');
    messageBox.className = success ? 'alert alert-success' : 'alert alert-error';
    messageBox.textContent = message;
    parent.replaceChildren(messageBox);
}
function td(value) { const element = document.createElement('td'); element.textContent = String(value ?? ''); return element; }
function showTab(name, button) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(p => p.classList.remove('active'));
    $('tab-' + name)?.classList.add('active');
    button.classList.add('active');
    if (name === 'reviews') loadReviews();
    if (name === 'account') refreshProfile();
}
async function loadCsrfToken() {
    try {
        const data = await api('/api/csrf-token');
        CSRF_TOKEN = data.csrfToken;
        if ($('csrfDisplay')) $('csrfDisplay').textContent = 'Loaded (session-bound; not shown in full)';
    } catch (e) {
        if ($('csrfDisplay')) $('csrfDisplay').textContent = 'Error loading token';
    }
}
const jsonHeaders = () => ({ 'Content-Type': 'application/json', 'CSRF-Token': CSRF_TOKEN });

function showAuthenticated(user) {
    $('loginPanel').classList.add('hidden');
    $('mainApp').classList.remove('hidden');
    $('headerUser').textContent = '👤 ' + user.username;
    $('logoutBtn').style.display = 'block';
    $('statUser').textContent = user.role;
    loadEnrollments();
    if (location.hash.length > 1) showTab('announce', document.querySelector('[data-tab="announce"]'));
}
async function restoreSession() {
    try { showAuthenticated(await api('/api/me')); }
    catch { /* Unauthenticated visitors keep the login screen. */ }
}
async function login() {
    try {
        if (!CSRF_TOKEN) await loadCsrfToken();
        const d = await api('/api/login', {
            method: 'POST', headers: jsonHeaders(),
            body: JSON.stringify({ username: $('username').value, password: $('password').value })
        });
        CSRF_TOKEN = d.csrfToken; // session is regenerated at login
        $('password').value = '';
        showAuthenticated(d.user);
    } catch (e) { status('loginResult', e.message, false); }
}
async function loadEnrollments() {
    const tbody = $('enrollTable');
    try {
        const rows = await api('/api/my-enrollments');
        tbody.replaceChildren();
        $('statCourses').textContent = String(rows.length);
        if (!rows.length) {
            const row = document.createElement('tr');
            const cell = td('No enrollments'); cell.colSpan = 4; row.appendChild(cell); tbody.appendChild(row);
            $('statGPA').textContent = 'N/A';
            return;
        }
        for (const r of rows) {
            const row = document.createElement('tr');
            [r.code,r.title,r.credits,r.grade].forEach(v => row.appendChild(td(v)));
            tbody.appendChild(row);
        }
        $('statGPA').textContent = rows[0].grade || 'N/A';
    } catch (e) { const row=document.createElement('tr'); row.appendChild(td(e.message)); tbody.replaceChildren(row); }
}
async function searchCourses() {
    const tbody = $('searchTable');
    try {
        const rows = await api('/api/courses/search?q=' + encodeURIComponent($('searchQuery').value));
        tbody.replaceChildren();
        if (!rows.length) { const row=document.createElement('tr'); const cell=td('No results'); cell.colSpan=4; row.appendChild(cell); tbody.appendChild(row); return; }
        for (const r of rows) {
            const row = document.createElement('tr');
            [r.id,r.code,r.title,r.credits].forEach(v=>row.appendChild(td(v)));
            tbody.appendChild(row);
        }
    } catch (e) { const row=document.createElement('tr'); const cell=td(e.message); cell.colSpan=4; row.appendChild(cell); tbody.replaceChildren(row); }
}
async function checkAvailability() {
    try {
        const d = await api('/api/courses/availability?q=' + encodeURIComponent($('availabilityQuery').value));
        status('availabilityResult', d.available ? 'Available: YES' : 'Available: NO');
    } catch(e) { status('availabilityResult', e.message, false); }
}
function showCourseDetail(rows) {
    const container = $('courseDetail');
    if (!Array.isArray(rows)) { container.textContent = rows.error || 'Unable to load course'; return; }
    if (!rows.length) { container.textContent = 'No course found.'; return; }
    const table = document.createElement('table');
    const header = document.createElement('tr');
    for (const label of ['ID', 'Code', 'Title', 'Credits', 'Lecturer ID']) {
        const cell = document.createElement('th'); cell.textContent = label; header.appendChild(cell);
    }
    table.appendChild(header);
    for (const course of rows) {
        const row = document.createElement('tr');
        for (const key of ['id', 'code', 'title', 'credits', 'lecturer_id']) {
            row.appendChild(td(course[key]));
        }
        table.appendChild(row);
    }
    container.replaceChildren(table);
}
async function getCourseDetail() {
    try {
        const d = await api('/api/courses/' + encodeURIComponent($('courseId').value));
        showCourseDetail(d);
    } catch (e) { $('courseDetail').textContent = 'Unable to load course: ' + e.message; }
}
async function postReview() {
    try {
        if (!CSRF_TOKEN) await loadCsrfToken();
        await api('/api/reviews', {
            method: 'POST', headers: jsonHeaders(),
            body: JSON.stringify({ course_id: $('reviewCourseId').value, content: $('reviewContent').value })
        });
        status('reviewPostResult', 'Review posted successfully.');
        $('reviewContent').value = '';
        await loadReviews();
    } catch (e) { status('reviewPostResult', e.message, false); }
}
async function loadReviews() {
    const box = $('reviewsContainer');
    const cid = $('filterCourseId').value;
    try {
        const rows = await api('/api/reviews' + (cid ? '?course_id=' + encodeURIComponent(cid) : ''));
        box.replaceChildren();
        if (!rows.length) { const p = document.createElement('p'); p.textContent = 'No reviews yet.'; box.appendChild(p); return; }
        for (const r of rows) {
            const wrapper = document.createElement('div'); wrapper.className = 'review-item';
            const meta = document.createElement('div'); meta.className = 'review-meta';
            meta.textContent = '👤 ' + r.username + ' • ' + new Date(r.created_at).toLocaleDateString() + ' • Course ID: ' + r.course_id;
            const content = document.createElement('div'); content.textContent = r.content;
            wrapper.append(meta, content); box.appendChild(wrapper);
        }
    } catch (e) { status('reviewPostResult', e.message, false); }
}
async function greet() {
    try {
        const msg = await api('/api/greet?name=' + encodeURIComponent($('greetName').value));
        $('greetBox').textContent = msg;
    } catch (e) { $('greetBox').textContent = e.message; }
}
function appendNote(text) {
    const div = document.createElement('div'); div.className = 'review-item'; div.textContent = text;
    $('notesBox').appendChild(div);
}
function addNote() { appendNote($('noteInput').value); $('noteInput').value = ''; }
function renderFragment() {
    if (location.hash.length < 2) return;
    let text;
    try { text = decodeURIComponent(location.hash.slice(1)); }
    catch { return; }
    let sharedNote = $('sharedNote');
    if (!sharedNote) {
        sharedNote = document.createElement('div');
        sharedNote.id = 'sharedNote'; sharedNote.className = 'review-item';
        $('notesBox').prepend(sharedNote);
    }
    sharedNote.textContent = text;
    if (!$('mainApp').classList.contains('hidden')) {
        showTab('announce', document.querySelector('[data-tab="announce"]'));
    }
}
async function refreshProfile() {
    try {
        const me = await api('/api/me');
        if ($('currentEmail')) $('currentEmail').textContent = me.email;
    } catch (e) { if ($('currentEmail')) $('currentEmail').textContent = e.message; }
}
async function changeEmail() {
    try {
        if (!CSRF_TOKEN) await loadCsrfToken();
        const d = await api('/api/change-email', {
            method: 'POST', headers: jsonHeaders(),
            body: JSON.stringify({ email: $('newEmail').value })
        });
        status('emailResult', 'Email updated to: ' + d.newEmail);
        refreshProfile();
    } catch (e) { status('emailResult', e.message, false); }
}
async function logout() {
    try {
        await api('/api/logout', { method: 'POST', headers: { 'CSRF-Token': CSRF_TOKEN } });
        location.reload();
    } catch (e) { status('emailResult', e.message, false); }
}
const actions = { login, logout, searchCourses, checkAvailability, getCourseDetail, postReview, loadReviews, greet, addNote, changeEmail };
document.addEventListener('click', event => {
    const tab = event.target.closest('[data-tab]');
    if (tab) { showTab(tab.dataset.tab, tab); return; }
    const action = event.target.closest('[data-action]');
    if (action && actions[action.dataset.action]) actions[action.dataset.action]();
});
window.addEventListener('hashchange', renderFragment);
renderFragment();
loadCsrfToken();
restoreSession();
