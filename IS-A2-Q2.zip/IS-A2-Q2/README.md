# UniPortal | 100-Mark Web Security Blue-Team Project

**University Education Portal:** a genuine database-backed web app delivered as two switchable versions of the same product. Coursework scope: **3 XSS types + CSRF + easy/intermediate/advanced SQL injection**, with defenses and reproducible tests.

> ⚠️ **LOCAL TRAINING ONLY.** The `vulnerable/` folder intentionally contains exploitable code. Both Express servers and the attacker server bind to `127.0.0.1` only. Use fictional, seeded accounts. Never deploy the vulnerable version to a public host, share a live tunnel, or load real student information.

## Stack and application functionality

- **Frontend:** responsive HTML/CSS/vanilla JavaScript with clean student-facing pages (no payload/attack instructions in either portal). Login, student dashboard and grades, course catalogue/search, availability checker, course details, user reviews, greeting, notice board, and account email change.
- **Backend:** Node.js >= 20, Express 4.x, express-session, MySQL 8.x (MariaDB may also work).
- **Database:** two independent, genuinely executed MySQL databases seeded with the same fictional university data. SQLi attacks use MySQL's real parser, `information_schema`, and query execution.
- **Safe-only protections:** MySQL prepared statements through `mysql2.execute`, strictly validated input, salted `crypto.scryptSync` hashes, session regeneration after login, a session-bound synchronizer CSRF token validated with constant-time comparison, secure DOM rendering (`textContent`), Helmet headers and a restrictive `script-src 'self'` Content Security Policy. Safe sessions have `HttpOnly`, `SameSite=Strict` (HTTPS `Secure` should be enabled in production).

## Project tree

```text
Uni_Portal_Corrected/
├── vulnerable/
│   ├── backend/{server.js,package.json,package-lock.json}
│   └── frontend/index.html
├── safe/
│   ├── backend/{server.js,package.json,package-lock.json}
│   └── frontend/{index.html,app.js}
├── attacker/{index.html,server.js}     # independent cross-origin CSRF site
├── tests/{integration.mjs,static-checks.mjs,browser_ui_smoke.py}
├── docs/{ATTACK_LAB.md,RUN_WINDOWS_XAMPP.md,FIX_SUMMARY.md,RUBRIC_AUDIT.md,VERIFICATION_STATUS.md,University_Portal_Attack_Evidence_Workbook_Updated.docx}
├── schema.sql                         # resets/creates TWO independent DBs
├── docker-compose.yml                 # optional MySQL 8
└── package.json                       # root test/start shortcuts
```

## Run locally (three terminals plus MySQL)

**Windows/XAMPP users:** follow [`docs/RUN_WINDOWS_XAMPP.md`](docs/RUN_WINDOWS_XAMPP.md). Import the included schema once. If you already imported it with the previous version, **do not re-import** just because you installed a frontend fix.

**1. Prerequisites:** Node 20+, npm, MySQL 8 with permission to create databases/users. MySQL must listen on `127.0.0.1:3306`. Use the local MySQL installation, or optionally start the included database container:

```bash
docker compose up -d --wait
```

The Docker MySQL image imports `schema.sql` **only on first boot with an empty named volume**. For an existing local MySQL instance, initialize the database manually from this repository's root:

```bash
mysql -u root -p < schema.sql
```

**WARNING:** `schema.sql` drops and recreates BOTH dedicated **training** databases (`university_portal_vulnerable` and `university_portal_safe`), wiping their previously added reviews and email changes. It does **not** touch other databases. Import with an administrator account. The script also creates limited-privilege lab users.

**2. Terminal A — Vulnerable Portal:**

```bash
cd vulnerable/backend
npm ci
npm start
# http://127.0.0.1:3001
```

**3. Terminal B — Safe Portal:**

```bash
cd safe/backend
npm ci
npm start
# http://127.0.0.1:3002
```

**4. Terminal C — CSRF attacker page:** from the repository root:

```bash
node attacker/server.js
# http://127.0.0.1:4000
```

The portals have **different cookies**, so opening both in separate tabs does not overwrite each other's sessions. You can use the header link to switch versions.

If your MySQL host, TCP port or credentials differ, set `DB_HOST`, `DB_PORT`, `DB_USER`, and `DB_PASSWORD` for **each backend process**. Default accounts are `uni_vuln_lab` / `local-lab-vulnerable` and `uni_safe_lab` / `local-lab-safe` respectively. Never put actual credentials in GitHub. The safe server accepts an optional `SAFE_SESSION_SECRET` environment variable; otherwise, it generates a new random secret on boot.

### Demo users (fictional, same login details in both versions)

| Username | Password | Role |
|---|---|---|
| `alice_s` | `alice123` | student |
| `bob_s` | `bob123` | student |
| `prof_khan` | `prof123` | lecturer |
| `admin` | `admin123` | admin |

The vulnerable database deliberately stores these *synthetic* passwords in plaintext; the safe database stores a **unique salted scrypt hash** for each. Never enter a personal password into the vulnerable portal.

## Checklist — required attacks versus safe defenses

| Requirement | Vulnerable version (works on real database/browser) | Safe version (blocking defense) |
|---|---|---|
| **Reflected XSS** | Untrusted `name` enters an HTML response `/api/greet`; browser `innerHTML` executes a correctly quoted image-error handler | `text/plain` response + `textContent` + CSP; payload displayed as text |
| **Stored XSS** | Review saved into the `reviews` SQL table; reader's `innerHTML` executes it | Authenticated, CSRF-protected review posting; JSON rendered through `textContent` |
| **DOM XSS** | Client JavaScript listens to `hashchange`, reads `location.hash`, inserts it through `innerHTML` without sending fragment to server | Client decodes fragment and uses `createElement` / `textContent`; script CSP |
| **CSRF** | Session-authenticated `POST /api/change-email` accepts a forged HTML form from attacker origin `:4000`, without token | Same URL requires a valid synchronizer token; attacker sees 403. Strict cookie an additional layer |
| **SQLi EASY** | Directly interpolated username/password in login query; authentication bypass | Prepared lookup; salted-password verification, minimal session object |
| **SQLi INTERMEDIATE** | `/api/courses/availability` has a string-interpolated SQL `COUNT` query; conditional predicate yields *only true/false* to infer a character | Prepared `LIKE ?`, same boolean-only UI never evaluates injected predicate |
| **SQLi ADVANCED** | `/api/courses/:id` raw SQL, 5 columns; `ORDER BY`, `DATABASE()`, `information_schema.tables`, `information_schema.columns`, `UNION` user data | Strict full-ID validation + prepared statement, blocked with 400. DB privileges isolate the data |

**Important nuance:** The malicious page on port 4000 is a *different origin* but the same *site* as port 3001 (hostname `127.0.0.1`). This makes the cross-origin CSRF attack reliable under modern `SameSite=Lax` browser behavior. It is genuine CSRF because a page at another origin forges an authenticated request. `SameSite=Strict` alone would **not** block this particular same-site, cross-origin request; the synchronizer token does. For a truly cross-*site* HTTP POST demonstration, HTTPS + `SameSite=None; Secure` and a separate hostname would be required.

## Evidence and exact payloads

The web interface is intentionally a normal University Portal. **No exploit payloads or implementation walkthroughs appear in the student-facing pages.** See **[docs/ATTACK_LAB.md](docs/ATTACK_LAB.md)** for all seven step-by-step attack demonstrations with safe counterparts, exact payloads, verification screenshots to capture, and notes about browser behavior. See **[docs/RUBRIC_AUDIT.md](docs/RUBRIC_AUDIT.md)** for the assessment matrix and **[docs/VERIFICATION_STATUS.md](docs/VERIFICATION_STATUS.md)** for exactly which tests passed here and which still need MySQL/browser validation.

## Automated tests (must have MySQL + both servers running)

From repository root:

```bash
npm run test:static    # source-level evidence checks, no database required
npm test               # real HTTP + MySQL: easy/blind/advanced SQLi, stored XSS, CSRF, auth and safe controls
```

`GET /api/health` responds with `{"database":"ok"}` only after successfully querying the selected DB. The integration test **does not fake database results**. It writes two demo reviews, then restores changed test emails. To fully reset review data, re-import `schema.sql` (destroys/reseeds both training databases).

An optional browser-only check is `python tests/browser_ui_smoke.py` (requires local Chromium and Playwright). It loads the real frontend code with *stubbed* API responses to verify actual browser event handlers but is **not** a database or CSRF E2E test.

For XSS execution/nonexecution and the cross-origin form cookie behavior, also perform the manual **browser** checks in the attack guide; HTTP tests alone cannot prove browser JavaScript execution.

## GitHub submission

1. Upload **this single `Uni_Portal_Corrected/` directory**, including both versions, `schema.sql`, the attacker page, the test scripts and docs. Do **not** upload `node_modules`, DB dumps, `.env` or real credentials.
2. Include screenshots/video evidence for each vulnerable exploit and its safe comparison as described in the lab guide. The guide is not itself a screenshot of completed tests.
3. In your submitted README, record actual test results *after running them on your computer*. GitHub source code alone doesn't establish that exploits execute.
4. No GitHub repository or public deployment is created by this package. Push it to your own GitHub account using your normal workflow.

### Limitations (for an honest blue-team report)

This is a **training application**, not production software: the vulnerable app is intentionally unsafe, credentials are published in the README, session stores are in memory, HTTP is used for localhost, and frontend account/authorization models are intentionally small. Running the safe version with HTTPS, a persistent session store, deployment secrets, structured logs and automated browser tests would be expected for production.
