-- University Portal, local training only. All users/emails are synthetic.
-- WARNING: Reset removes BOTH training databases and their seeded reviews.
DROP DATABASE IF EXISTS university_portal_vulnerable;
DROP DATABASE IF EXISTS university_portal_safe;
CREATE DATABASE university_portal_vulnerable CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE university_portal_safe CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Different least-privilege accounts prevent the SQLi lab from reading the safe DB.
DROP USER IF EXISTS 'uni_vuln_lab'@'%';
DROP USER IF EXISTS 'uni_safe_lab'@'%';
CREATE USER 'uni_vuln_lab'@'%' IDENTIFIED BY 'local-lab-vulnerable';
CREATE USER 'uni_safe_lab'@'%' IDENTIFIED BY 'local-lab-safe';
GRANT SELECT, INSERT, UPDATE ON university_portal_vulnerable.* TO 'uni_vuln_lab'@'%';
GRANT SELECT, INSERT, UPDATE ON university_portal_safe.* TO 'uni_safe_lab'@'%';

USE university_portal_vulnerable;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL, -- DELIBERATELY PLAINTEXT: demonstration data only
  email VARCHAR(100) NOT NULL,
  role ENUM('student','lecturer','admin') DEFAULT 'student',
  api_token VARCHAR(64)
);
CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) UNIQUE NOT NULL,
  title VARCHAR(150) NOT NULL,
  credits INT DEFAULT 3,
  lecturer_id INT,
  FOREIGN KEY (lecturer_id) REFERENCES users(id)
);
CREATE TABLE enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  grade VARCHAR(5) DEFAULT 'N/A',
  FOREIGN KEY (student_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
INSERT INTO users (username,password,email,role,api_token) VALUES
 ('admin','admin123','admin@university.test','admin','synthetic-admin-token'),
 ('prof_khan','prof123','prof@university.test','lecturer','synthetic-prof-token'),
 ('alice_s','alice123','alice@student.test','student','synthetic-alice-token'),
 ('bob_s','bob123','bob@student.test','student','synthetic-bob-token');
INSERT INTO courses (code,title,credits,lecturer_id) VALUES
 ('CS101','Introduction to Computer Science',3,2),
 ('CS201','Data Structures and Algorithms',3,2),
 ('CS301','Database Systems',3,2),
 ('CS401','Web Security and Cryptography',3,2),
 ('MATH101','Calculus I',3,2);
INSERT INTO enrollments (student_id,course_id,grade) VALUES
 (3,1,'A'),(3,2,'B+'),(3,3,'A-'),(4,1,'B'),(4,4,'A'),(4,5,'C+');
INSERT INTO reviews (user_id,course_id,content) VALUES
 (3,1,'Great introductory course, very well structured!'),
 (4,1,'Professor explains concepts clearly.'),
 (3,2,'Challenging but rewarding.');

USE university_portal_safe;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL, -- salted scrypt, not a plaintext password
  email VARCHAR(100) NOT NULL,
  role ENUM('student','lecturer','admin') DEFAULT 'student'
);
CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) UNIQUE NOT NULL,
  title VARCHAR(150) NOT NULL,
  credits INT DEFAULT 3,
  lecturer_id INT,
  FOREIGN KEY (lecturer_id) REFERENCES users(id)
);
CREATE TABLE enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  grade VARCHAR(5) DEFAULT 'N/A',
  FOREIGN KEY (student_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
INSERT INTO users (username,password_hash,email,role) VALUES
 ('admin','scrypt$7c4a0e90b48207c0593380cb115b0fe5$db037aec3c4cafb1bd914ff70242522d0c047f5ca1d971a1529d47c44c154ea1ebe0e024b47bc57378c41cd8034b86baa42f42dc443c8b011f99e62c5034af7d','admin@university.test','admin'),
 ('prof_khan','scrypt$1f462a8b03273c2fd3c5378e29776201$89573eeedd7b243f0f1be3afa2a9baade4b5c3aa99ee24149031ad34f70f1586839d1ae68e0441ef378e4db058568c625a659dd33a1abc2fd2ece6ce2fca8d91','prof@university.test','lecturer'),
 ('alice_s','scrypt$17a9f7c1b60fc84f3ee02713630269ba$605b476e0f39149323c163f2abcb27496960953dee16b55468c85b29176ea23e6991ee67a022ab1f157350b2a3d2e94ceb10cd2f056693c1b8b1f673d49131be','alice@student.test','student'),
 ('bob_s','scrypt$452742aaa3b796ea7b49726a09b98162$99db0cecdca5d1b4afeaf962c2ffbfc0170e31fe66d1767c0dc5d7817f7efaba117ff8aed8c7b3f4ee6f32f21f941a1185d762ca374c16c2ebcc8a9d40955e15','bob@student.test','student');
INSERT INTO courses (code,title,credits,lecturer_id) VALUES
 ('CS101','Introduction to Computer Science',3,2),
 ('CS201','Data Structures and Algorithms',3,2),
 ('CS301','Database Systems',3,2),
 ('CS401','Web Security and Cryptography',3,2),
 ('MATH101','Calculus I',3,2);
INSERT INTO enrollments (student_id,course_id,grade) VALUES
 (3,1,'A'),(3,2,'B+'),(3,3,'A-'),(4,1,'B'),(4,4,'A'),(4,5,'C+');
INSERT INTO reviews (user_id,course_id,content) VALUES
 (3,1,'Great introductory course, very well structured!'),
 (4,1,'Professor explains concepts clearly.'),
 (3,2,'Challenging but rewarding.');
